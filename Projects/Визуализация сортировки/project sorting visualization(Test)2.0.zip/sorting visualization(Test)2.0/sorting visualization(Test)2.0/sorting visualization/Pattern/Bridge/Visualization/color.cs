﻿using System.Threading;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;
namespace sorting_visualization.Pattern.Bridge.Visualization
{
    static class color
    {
        static public void SetGreen(int index1, Line[] lines)
        {
            //изменение цвета палочки на зеленый, которые на своём месте
            bridge.dispatcher.BeginInvoke(DispatcherPriority.Normal, (ThreadStart)delegate ()
            {
                lines[index1].Stroke = Brushes.Green;
            });
        }
        static public void SetOrange(int index1, int index2, Line[] lines)
        {
            //изменение цвета палочки на оранжевый, которые проверяются
            bridge.dispatcher.BeginInvoke(DispatcherPriority.Normal, (ThreadStart)delegate ()
            {
                lines[index1].Stroke = Brushes.Orange;
                lines[index2].Stroke = Brushes.Orange;
            });
        }
        static public void SetRed(int index1, int index2, Line[] lines)
        {
            //изменение цвета палочки на красный, которые ещё не на своих местах
            bridge.dispatcher.BeginInvoke(DispatcherPriority.Normal, (ThreadStart)delegate ()
            {
                lines[index1].Stroke = Brushes.Red;
                lines[index2].Stroke = Brushes.Red;
            });
        }
    }
}
