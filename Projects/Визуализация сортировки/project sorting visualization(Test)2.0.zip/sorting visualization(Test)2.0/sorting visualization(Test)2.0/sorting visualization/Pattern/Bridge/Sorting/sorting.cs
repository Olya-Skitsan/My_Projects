﻿using System;
using System.Threading;
using System.Windows.Controls;
using System.Windows.Shapes;
using sorting_visualization.Pattern.Bridge.Visualization;
namespace sorting_visualization.Pattern.Bridge
{
    static class sorting
    {
        static public int[] ArrayGeneration(int N)
        {
            //Генерирование массива значений от 5 до 175
            Random random = new Random();
            int[] array = new int[N];
            for (int i = 0; i < array.Length; i++)
                array[i] = random.Next(5, 175);
            return array;
        }
        static public int[] BulbSort(int[] array, Line[] lines,Label[]labels)
        {
            //сортировка пузырьком
            for (int i = 0; i < array.Length; i++)
            {
                for (int j = i + 1; j < array.Length; j++)
                {
                    color.SetOrange(i, j, lines); //установка оранжевого цвета
                    if (array[j] < array[i])
                    {   
                        int temp = array[j];
                        array[j] = array[i];
                        array[i] = temp;
                        visualization.SwapLines(i, j, lines, array); //изменение положения палочек
                        visualization.PrintArray(array, labels); //печать массива
                    }
                    Thread.Sleep(bridge.d); //задержка
                    color.SetRed(i, j, lines); //установка красного цвета
                }
                color.SetGreen(i, lines);//установка зеленого цвета
            }
            return array;
        }
    }
}
