﻿using System.Threading;
using System.Windows.Controls;
using System.Windows.Shapes;
using System.Windows.Threading;
using sorting_visualization.Pattern.Bridge.Visualization;
namespace sorting_visualization.Pattern.Bridge
{
    static class bridge
    {
        static public int n = 20;//минимальное количество значение 
        static public int d = 100;//минимальная задержка 
        static public int[] numbers;//массив значений
        static public Line[] lines;//массив линий 
        static public Label[] labels; //массив ярлыков
        static public Thread SortingThread;//экземпляр класса Thread для отдельного потока
        static public Dispatcher dispatcher;
        static public StackPanel PanelForLines;
        static public Grid GridForNumbers;
        static public void GenerationArray()
        {
            numbers = sorting.ArrayGeneration(n);
        }
        static public void LinesInitialize()
        {
            lines = visualization.InitializeLines(numbers);
            for (int i = 0; i < lines.Length; i++)
                GridForNumbers.Children.Add(lines[i]);
        }
        static public void LabelsInitialize()
        {
            labels = visualization.InitializeLabel(numbers);
            for (int i = 0; i < labels.Length; i++)
                PanelForLines.Children.Add(labels[i]);
        }
        static public void StartSort()
        {
            numbers = sorting.BulbSort(numbers, lines, labels);
        }
    }
}
