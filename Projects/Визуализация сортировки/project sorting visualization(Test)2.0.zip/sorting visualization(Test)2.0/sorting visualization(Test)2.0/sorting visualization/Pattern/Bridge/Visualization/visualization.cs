﻿using System;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Threading;
using System.Windows.Controls;
using System.Windows;
namespace sorting_visualization.Pattern.Bridge.Visualization
{
    static class visualization 
    {
        static private readonly double r = 130;//длина палочки
        static private readonly double a = 140, b = 230;//отступы от краёв формы для построения палочек
        static public Label[] InitializeLabel(int[] array)
        {
            //создание ярлыка с нужными характеристиками
            Label[] arrayLabel = new Label[array.Length];
            for (int i = 0; i < array.Length; i++)
            {
                Label label = new Label();
                label.Background = Brushes.Wheat;
                label.FontSize = 30;
                label.Content = array[i];
                label.BorderThickness = new Thickness(4);
                arrayLabel[i] = label;
            }
            return arrayLabel;
        }
        static public Line[] InitializeLines(int[] array)
        {
            //создание палочки с нужными характеристиками
            Line[] arrayLine = new Line[array.Length];
            for (int i = 0; i < array.Length; i++)
            {
                Line line = new Line();
                line.X1 = a + ((i + 1) * 30);
                line.Y1 = b;
                line.X2 = -Math.Cos(((double)array[i] / 180) * Math.PI) * r + line.X1;
                line.Y2 = -Math.Sin(((double)array[i] / 180) * Math.PI) * r + line.Y1;
                line.StrokeThickness = 2;
                line.Stroke = Brushes.Red;
                arrayLine[i] = line;
            }
            return arrayLine;
        }
        static public void SwapLines(int index1, int index2 , Line[] lines , int[] array)
        {
            //изменение положения двух палочек 
            bridge.dispatcher.BeginInvoke(DispatcherPriority.Normal, (ThreadStart)delegate ()
            {
                double Onex1 = lines[index1].X1;
                double Oney1 = lines[index1].Y1;
                double Twox1 = lines[index2].X1;
                double Twoy1 = lines[index2].Y1;
                lines[index2].X1 = Onex1;
                lines[index2].Y1 = Oney1;
                lines[index2].X2 = -Math.Cos(((double)array[index2] / 180) * Math.PI) * r + lines[index2].X1;
                lines[index2].Y2 = -Math.Sin(((double)array[index2] / 180) * Math.PI) * r + lines[index2].Y1;
                lines[index1].X1 = Twox1;
                lines[index1].Y1 = Twoy1;
                lines[index1].X2 = -Math.Cos(((double)array[index1] / 180) * Math.PI) * r + lines[index1].X1;
                lines[index1].Y2 = -Math.Sin(((double)array[index1] / 180) * Math.PI) * r + lines[index1].Y1;
            });
            Line temp = lines[index1];
            lines[index1] = lines[index2];
            lines[index2] = temp;
        }
        static public void PrintArray(int[] array, Label[] labels)
        {
            //печать массива значений
            bridge.dispatcher.BeginInvoke(DispatcherPriority.Normal, (ThreadStart)delegate ()
            {
                bridge.PanelForLines.Children.Clear();
                for (int i = 0; i < labels.Length; i++)
                    labels[i].Content = array[i].ToString();
                for (int i = 0; i < labels.Length; i++)
                    bridge.PanelForLines.Children.Add(labels[i]);
            });
        }
    }
}
