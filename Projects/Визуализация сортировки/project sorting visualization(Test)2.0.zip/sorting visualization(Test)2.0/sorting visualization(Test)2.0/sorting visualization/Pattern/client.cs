﻿using System.Threading;
using System.Windows.Threading;
using System.Windows.Controls;
using sorting_visualization.Pattern.Bridge;
namespace sorting_visualization.Pattern
{
    static class client
    {
        static public void InitializeRandom(int N, int D, Dispatcher  dispatcher , StackPanel stackpanel, Grid grid)
        {
            //инициализация палочек и значений
            bridge.n = N;
            bridge.d = D;
            bridge.dispatcher = dispatcher;
            bridge.PanelForLines = stackpanel;
            bridge.GridForNumbers = grid;
            bridge.GenerationArray();
            bridge.GridForNumbers.Children.Clear();
            bridge.LinesInitialize();
            bridge.PanelForLines.Children.Clear();
            bridge.LabelsInitialize();
        }
        static public void CloseWorking()
        {
            if (bridge.SortingThread != null)
                bridge.SortingThread.Abort();
        }
        static public void Start(OnOffbuttons buttons)
        {
            buttons(false);
            bridge.SortingThread = new Thread(delegate ()
            {
                bridge.StartSort();
                bridge.dispatcher.BeginInvoke(DispatcherPriority.Normal, (ThreadStart)delegate ()
                {
                    buttons(true);
                });
            });
            bridge.SortingThread.Start();
        }
    }
}
