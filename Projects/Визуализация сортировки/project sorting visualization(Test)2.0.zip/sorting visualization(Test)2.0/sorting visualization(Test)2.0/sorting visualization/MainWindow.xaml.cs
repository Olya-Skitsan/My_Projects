﻿using System;
using System.Windows;
using sorting_visualization.Pattern;
namespace sorting_visualization
{
    delegate void OnOffbuttons(bool tf);
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Closed += EndProgram;
            client.InitializeRandom((int)InputN.Value, (int)InputDelay.Value,Dispatcher,OutputTextBox,DrawingCanvas);
        }
        private void EndProgram(object sender, EventArgs e)
        {
            client.CloseWorking();
            Close();
        }
        private void RandomButton_Click(object sender, RoutedEventArgs e)
        {
            client.InitializeRandom((int)InputN.Value, (int)InputDelay.Value, Dispatcher, OutputTextBox, DrawingCanvas);
        }
        private void InputN_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Quantity.Content = ((int)InputN.Value).ToString();
        }
        private void InputDelay_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Delay.Content = ((int)InputDelay.Value).ToString();
        }
        private void ButtonsOnOff(bool tf)
        {
            RunButton.IsEnabled = tf;
            RandomButton.IsEnabled = tf;
            InputN.IsEnabled = tf;
            InputDelay.IsEnabled = tf;
        }
        private void RunSortingButton_Click(object sender, RoutedEventArgs e)
        {
            OnOffbuttons buttons = ButtonsOnOff;
            client.Start(buttons);
        }
    }
}
