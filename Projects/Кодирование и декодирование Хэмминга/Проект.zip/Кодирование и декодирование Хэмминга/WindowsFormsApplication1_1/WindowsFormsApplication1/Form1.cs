﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace WindowsFormsApplication1
{

    public partial class Form1 : Form
    {
  
        public Form1()
        {
     
            InitializeComponent();
            {
          
            }
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;
            textBox2.Enabled = false;
            textBox6.Enabled = false;
            textBox4.Enabled = false;
            textBox5.Enabled = false;

        }
       
        private void button1_Click(object sender, EventArgs e)
        {
            StringBuilder sb = new StringBuilder();
            foreach (byte b in System.Text.Encoding.UTF8.GetBytes(textBox1.Text))
            sb.Append(Convert.ToString(b, 2).PadLeft(8, '0')).Append(' ');
            string binaryStr = sb.ToString();
            textBox2.Text = sb.ToString();

        }
       
        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
            }
            else e.Handled = false;
        
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (textBox2.Text.Length > 0)
            {
                button2.Enabled = true;
            }
            if (textBox2.Text.Length > 0)
            {
                textBox6.Enabled = true;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

            if (textBox1.Text.Length > 0)
            {
                button1.Enabled = true;
            }
            if (textBox1.Text.Length > 0)
            {
                textBox2.Enabled = true;
            }
           
        }

        private void button2_Click(object sender, EventArgs e)
        {

            int[] code = new int[12];
            string t = textBox2.Text;//входящий код
            string rez = "";//код хемминга
            int n=8;
            int[] m = new int [8];
      
            int[,] matrix = new int[4, 12]{{1,0,1,0,1,0,1,0,1,0,1,0},
                                            {0,1,1,0,0,1,1,0,0,1,1,0},
                                           {0,0,0,1,1,1,1,0,0,0,0,1},
                                           {0,0,0,0,0,0,0,1,1,1,1,1}};
            int[] add = new int[4];//контрольные биты
            for (int i = 0; i < t.Length; i += 8) // i - номер символа в строке t
            {
                code[0] = code[1] = code[3] = code[7] = 0;
                code[2] = m[0];
                for (int j = 0; j < n; ++j)
                {
                    if (t[i] == '0')
                        m[j] = 0;
                    else if (t[i] == '1') m[j] = 1;
                }
                for (int j = 1; j <= 3; ++j)
                {
                    code[j + 3] = m[j];
                }
                for (int j = 4; j < 8; ++j)
                {
                    code[j + 4] = m[j];
                }
                int poz;
                for (int j = 0; j <4; ++j)
                {
                    add[j]=0;
                    poz = 1;
                    for (int k = 0; k < 12; ++k)
                        add[j] += code[k] * matrix[j, k];
                    add[j] %= 2;
                    poz<<=j;
                    code[poz-1]=add[j];
                 }
                 for (int j = 0; j <12; ++j)
                 {
                      rez += code[j] == 0 ? "0" : "1";

                 }
                }
                textBox6.Text = rez;
          
             }

       private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            if (textBox4.Text.Length > 0)
            {
                textBox5.Enabled = true;
            }
            if (textBox4.Text.Length > 0)
            {
                textBox5.Enabled = true;
            }
        }

        private void textBox6_TextChanged_1(object sender, EventArgs e)
        {
            if (textBox6.Text.Length > 0)
            {
                button3.Enabled = true;
            }
            if (textBox6.Text.Length > 0)
            {
                textBox4.Enabled = true;
            }
        }
        }

       
    }

