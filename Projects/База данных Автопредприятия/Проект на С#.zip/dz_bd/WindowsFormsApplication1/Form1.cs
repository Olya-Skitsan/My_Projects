﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
      //  public object dd { get; set; }private readonly АвтоДБ_1 _dbAvto;
        public Form1()
        {
            InitializeComponent();
            dateTimePicker1.Format = DateTimePickerFormat.Time;
            dateTimePicker2.Format = DateTimePickerFormat.Time;
  

        }
        private void Form1_Load(object sender, EventArgs e)
        {
            //SqlCommand command = new SqlCommand("SELECT * FROM [Tehnika]", sqlConnection);
            //int number = command.ExecuteNonQuery();
            //try
            //{
            //   sqlReader = await command.ExecuteReaderAsync();
            //   while (await sqlReader.ReadAsync())
            //    {
            //        listBox1.Items.Add(Convert.ToString(sqlReader["id_mashin"]) + "    " + Convert.ToString(sqlReader["model"]) + "       " + Convert.ToString(sqlReader["id_Voditelya"]));
            //    }
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.Message.ToString(), ex.Source.ToString(), MessageBoxButtons.OK, MessageBoxIcon.Error);
            //}
            //finally
            //{
            //    if (sqlReader != null)
            //        sqlReader.Close();
            //}

        }

        //public SqlConnection sqlConnection { get; set; }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {


            string connectionString = @"Data Source= A203-14; Initial Catalog = АвтоБД_1;Integrated Security=True";
            string sqlExpression = "INSERT INTO [Tehnika] (model,id_Voditelya) VALUES (@model,@id_Voditelya)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand(sqlExpression, connection);

                    command.Parameters.AddWithValue("model", textBox2.Text);
                    command.Parameters.AddWithValue("id_Voditelya", textBox1.Text);
                    if (command.ExecuteNonQuery() == 1)
                        MessageBox.Show("Запись успешно добавлена!");
                    connection.Close();
                }
                // int number = command.ExecuteNonQuery();
                //label7.Text= command.ExecuteNonQuery();


                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string connectionString = @"Data Source= A203-14; Initial Catalog = АвтоБД_1;Integrated Security=True";

            string sqlExpression = "UPDATE [Detali] SET [id_polomki]=@id_polomki, [id_mashin]=@id_mashin,[kol_vo_detaley]=@kol_vo_detaley WHERE [id_detali]=@id_detali";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand(sqlExpression, connection);
                    command.Parameters.AddWithValue("id_detali", textBox3.Text);
                    command.Parameters.AddWithValue("id_polomki", textBox4.Text);
                    command.Parameters.AddWithValue("id_mashin", textBox5.Text);
                    command.Parameters.AddWithValue("kol_vo_detaley", textBox6.Text);

                    if (command.ExecuteNonQuery() == 1)
                        MessageBox.Show("Запись успешно изменена!");
                    connection.Close();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string connectionString = @"Data Source= A203-14; Initial Catalog = АвтоБД_1;Integrated Security=True";
            string sqlExpression = "DELETE  FROM [Jobs] WHERE id_Jobs=@id_Jobs";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand(sqlExpression, connection);
                    command.Parameters.AddWithValue("id_Jobs", textBox7.Text);
                    if (command.ExecuteNonQuery() == 1)
                        MessageBox.Show("Запись успешно удалена!");
                    connection.Close();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            string connectString = @"Data Source= A203-14; Initial Catalog = АвтоБД_1;Integrated Security=True";
            SqlConnection myConnection = new SqlConnection(connectString);
            myConnection.Open();
            string query = "SELECT * FROM [Tehnika]";
            SqlCommand command = new SqlCommand(query, myConnection);
            SqlDataReader reader = command.ExecuteReader();
            List<string[]> data = new List<string[]>();
            while (reader.Read())
            {
                data.Add(new string[3]);
                data[data.Count - 1][0] = reader[0].ToString();
                data[data.Count - 1][1] = reader[1].ToString();
                data[data.Count - 1][2] = reader[2].ToString();
            }
            reader.Close();
            myConnection.Close();
            foreach (string[] s in data)
                dataGridView1.Rows.Add(s);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            string connectString = @"Data Source= A203-14; Initial Catalog = АвтоБД_1;Integrated Security=True";

            SqlConnection myConnection = new SqlConnection(connectString);

            myConnection.Open();
            string query = "SELECT * FROM [Detali]";
            SqlCommand command = new SqlCommand(query, myConnection);
            SqlDataReader reader = command.ExecuteReader();
            List<string[]> data = new List<string[]>();
            while (reader.Read())
            {
                data.Add(new string[4]);

                data[data.Count - 1][0] = reader[0].ToString();
                data[data.Count - 1][1] = reader[1].ToString();
                data[data.Count - 1][2] = reader[2].ToString();
                data[data.Count - 1][3] = reader[3].ToString();
            }
            reader.Close();
            myConnection.Close();
            foreach (string[] s in data)
                dataGridView2.Rows.Add(s);
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            string connectString = @"Data Source= A203-14; Initial Catalog = АвтоБД_1;Integrated Security=True";
            SqlConnection myConnection = new SqlConnection(connectString);
            myConnection.Open();
            string query = "SELECT * FROM [Jobs]";
            SqlCommand command = new SqlCommand(query, myConnection);
            SqlDataReader reader = command.ExecuteReader();
            List<string[]> data = new List<string[]>();
            while (reader.Read())
            {
                data.Add(new string[3]);
                data[data.Count - 1][0] = reader[0].ToString();
                data[data.Count - 1][1] = reader[1].ToString();
                data[data.Count - 1][2] = reader[2].ToString();
            }
            reader.Close();
            myConnection.Close();
            foreach (string[] s in data)
                dataGridView3.Rows.Add(s);
        }

        private void button5_Click(object sender, EventArgs e)
           {
            string connectString = @"Data Source= A203-14; Initial Catalog = АвтоБД_1;Integrated Security=True";
            string sqlExpression = "dbo.Zadanie112";
          SqlConnection connection = new SqlConnection(connectString);
            
                connection.Open();
                SqlCommand command = new SqlCommand(sqlExpression, connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("PayDay1", "2017-01-01 00:00:00");
                command.Parameters.AddWithValue("PayDay2", "2017-03-30 00:00:00");
                SqlDataReader reader = command.ExecuteReader();
                List<string[]> data = new List<string[]>();
                    while (reader.Read())
                    {
                        data.Add(new string[2]);
                        data[data.Count - 1][0] = reader[0].ToString();
                        data[data.Count - 1][1] = reader[1].ToString();
                    }
                    reader.Close();
                    connection.Close();
                    foreach (string[] s in data)
                        dataGridView4.Rows.Add(s);
                }

        private void button7_Click(object sender, EventArgs e)
        {
            string connectString = @"Data Source= A203-14; Initial Catalog = АвтоБД_1;Integrated Security=True";
            string sqlExpression = "dbo.Proc1";
            SqlConnection connection = new SqlConnection(connectString);
            connection.Open();
            SqlCommand command = new SqlCommand(sqlExpression, connection);
            command.CommandType = System.Data.CommandType.StoredProcedure;
            SqlDataReader reader = command.ExecuteReader();
            List<string[]> data = new List<string[]>();
            while (reader.Read())
            {
                data.Add(new string[2]);
                data[data.Count - 1][0] = reader[0].ToString();
                data[data.Count - 1][1] = reader[1].ToString();
            }
            reader.Close();
            connection.Close();
            foreach (string[] s in data)
                dataGridView5.Rows.Add(s);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string connectString = @"Data Source= A203-14; Initial Catalog = АвтоБД_1;Integrated Security=True";
            string sqlExpression = "SELECT * FROM [MaxDay]";
            SqlConnection connection = new SqlConnection(connectString);
            connection.Open();
            SqlCommand command = new SqlCommand(sqlExpression, connection);
            SqlDataReader reader = command.ExecuteReader();
            List<string[]> data = new List<string[]>();
            while (reader.Read())
            {
                data.Add(new string[2]);
                data[data.Count - 1][0] = reader[0].ToString();
                data[data.Count - 1][1] = reader[1].ToString();
            }
            reader.Close();
            connection.Close();
            foreach (string[] s in data)
                dataGridView6.Rows.Add(s);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            string connectString = @"Data Source= A203-14; Initial Catalog = АвтоБД_1;Integrated Security=True";
            string sqlExpression = "SELECT * FROM dbo.Zadanie3_3(@vid_p)";
            SqlConnection connection = new SqlConnection(connectString);
            connection.Open();
            SqlCommand command = new SqlCommand(sqlExpression, connection);
            command.Parameters.AddWithValue("vid_p", textBox8.Text);
           // command.CommandType = System.Data.CommandType.StoredProcedure;
            SqlDataReader reader = command.ExecuteReader();
            List<string[]> data = new List<string[]>();
            while (reader.Read())
            {
                data.Add(new string[1]);
                data[data.Count - 1][0] = reader[0].ToString();
      
            }
            reader.Close();
            connection.Close();
            foreach (string[] s in data)
                dataGridView7.Rows.Add(s);
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void button11_Click(object sender, EventArgs e)
        {
            string connectString = @"Data Source= A203-14; Initial Catalog = АвтоБД_1;Integrated Security=True";
            string sqlExpression = "dbo.Zadanie3_33333";
            
            SqlConnection connection = new SqlConnection(connectString);
            connection.Open();
            SqlCommand command = new SqlCommand(sqlExpression, connection);
            command.CommandType = System.Data.CommandType.StoredProcedure;
            
            //command.CommandType = System.Data.CommandType.StoredProcedure;
            SqlDataReader reader1 = command.ExecuteReader();
            //List<string[]> data = new List<string[]>();
            
                //while (reader1.Read())
                //{
                    //data.Add(new string[2]);
                    //data[data.Count - 1][0] = reader[0].ToString();
                    //data[data.Count - 1][1] = reader[1].ToString();
                //}
            
            //else listBox1.Items.Add("cdj");
            reader1.Close();
            connection.Close();
            //foreach (string[] s in data)
            //    dataGridView5.Rows.Add(s);
        }

        private void button12_Click(object sender, EventArgs e)
        {
            string connectString = @"Data Source= A203-14; Initial Catalog = АвтоБД_1;Integrated Security=True";
            string sqlExpression = "SELECT * FROM [dbo].[ufn_CarReports](@vid_polomki)";
            SqlConnection connection = new SqlConnection(connectString);
            connection.Open();
            SqlCommand command = new SqlCommand(sqlExpression, connection);
            command.Parameters.AddWithValue("vid_polomki", textBox10.Text);
            SqlDataReader reader = command.ExecuteReader();
            List<string[]> data = new List<string[]>();
            while (reader.Read())
            {
                data.Add(new string[2]);
                data[data.Count - 1][0] = reader[0].ToString();
                data[data.Count - 1][1] = reader[1].ToString();
            }
            reader.Close();
            connection.Close();
            foreach (string[] s in data)
                dataGridView8.Rows.Add(s);
        }
            }
        

    
    }

        
            

