﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        System.IO.StreamReader sr;
        double[] x;
        Система_линейных_уравнений s;
        bool Решение_существует;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            button2.Enabled = true;
            s = new Система_линейных_уравнений();
            s.Чтение_из_файла(sr);//("c:\\System.txt");
            Решение_существует=s.Решение(out x);
            if (Решение_существует) s.запись_в_файл(x);
         }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (Решение_существует)
            {
                int n = s.dim;
                DataGridViewTextBoxCell txtCell;
                for (int i = 0; i < n - 1; ++i)
                    dataGridView1.Rows.Add();
                for (int i = 0; i < n; ++i)
                {
                    txtCell =
                         (DataGridViewTextBoxCell)dataGridView1.Rows[i].Cells[0];
                    txtCell.Value = "x" + i.ToString();
                    txtCell =
                         (DataGridViewTextBoxCell)dataGridView1.Rows[i].Cells[1];
                    txtCell.Value = "=";
                    txtCell =
                         (DataGridViewTextBoxCell)dataGridView1.Rows[i].Cells[2];
                    txtCell.Value = x[i].ToString();

                }
            }
            else
            {
                dataGridView1.Visible = false;
                label2.Visible = true;
            }
        }

        private void прочитатьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                sr = new
                   System.IO.StreamReader(openFileDialog1.FileName);
                
            }  
        }

    }
}
