﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace WindowsFormsApplication1
{
    class Система_линейных_уравнений
    {
        public int dim; // размерность системы
        double [,]a; //коэффициенты системы
        double[] b; // матрица свободных членов
        public
        void Чтение_из_файла(StreamReader sr)
        {
            string StrLine;//строка для чтения очередной строки из файла
            string[] StrArr;//элементы стороки, разделенные пробелом
            char[] differ = new char[] { ' ' };//разделитель между двумя элементами массива
      
            StrLine = sr.ReadLine();//чтение размерностей массива
            dim = int.Parse(StrLine);
           
            a = new double[dim, dim];//инициализация массива
            b = new double[dim];

            //Построчное считывание данных
            
            for (int i = 0; i < dim; i++)
            {
                StrLine = sr.ReadLine();//чтение очередной строки
                StrArr = StrLine.Split(differ);//раздление на элементы
                for(int j = 0; j < dim; j++)
                {
                    a[i,j] = int.Parse(StrArr[j]);//преобразование к числовому виду
                }
                b[i] = int.Parse(StrArr[dim]);
            }
            sr.Close();

          
        }


        public bool Решение(out double[] x)
        {
            double eps = 1e-5;
            bool solution_exist=true;
            x = new double[dim];
            int [] row = new int [dim]; //номера строк разрешающих элементов
            int [] col = new int[dim];  //номера столбцов разрешающих элементов
            for (int k=0;k<dim && solution_exist;++k)     //k-номер итерации 
            {                               
               //1.выбор разрещающего элемента
              int r = 0;//номер строки разрещшающего элемента
              int s = 0;//номер столбца разрешающего элемента
               //row[k] = 0;
               //col[k] = 0;
               double max = Double.MinValue;
               for (int i = 0; i < dim; ++i) // номера строк матрицы А
               {   // индекс не должен быть в массиве row
                   int w = 0;
                   while (w < k && row[w] != i) ++w;
                   if (w==k)
                       for (int j = 0; j < dim; ++j)      // номера столбцов матрицы А
                       {
                           w = 0;
                           while (w < k && col[w] != j) ++w;
                           if (w == k)
                               if (Math.Abs(a[i, j]) > max)
                               {
                                   max=Math.Abs(a[i, j]);
                                   row[k] = i;
                                   col[k] = j;
                               }
                       }
                 }
               r = row[k];
               s = col[k];
               if (Math.Abs(a[r, s]) > eps)
               {
                   for (int i = 0; i < dim; ++i) // номера строк матрицы А
                   {
                       if (i == r)
                       {
                           for (int j = 0; j < dim; ++j)      // номера столбцов матрицы А
                               a[i, j] /= a[r, s];
                           b[i] /= a[r, s];
                       }
                       else
                       {
                           for (int j = 0; j < dim; ++j)      // номера столбцов матрицы А
                               a[i, j] -= a[i, s] / a[r, s] * a[r, j];
                           b[i] -= a[i, s] / a[r, s] * b[r];
                       }
                   }
                   запись_в_файл(row); 
                   запись_в_файл(col);
                   запись_в_файл(a, b);
               }
               else solution_exist = false;

           }
            if (solution_exist)
            for (int j = 0; j < dim; ++j)
                x[row[j]] = b[j];
            return solution_exist;
           
    }
        public void запись_в_файл(double[] x)
        {
            StreamWriter sw = new StreamWriter("out.txt", true);
            for (int i = 0; i < dim; i++)
                 sw.Write("{0} ", x[i]);
            sw.WriteLine();
            sw.Close();
        }
        public void запись_в_файл(double[,] a, double [] b)
        {
            StreamWriter sw = new StreamWriter("out.txt", true);
         
            for (int i = 0; i < dim; i++)
            {
                for (int j = 0; j < dim; j++)
                {
                    sw.Write("{0} ", a[i, j]);
                }
                sw.Write("{0} ", b[i]);
                sw.WriteLine();
            }
            sw.WriteLine();
            sw.Close();

        }
        public void запись_в_файл(int[] x)
        {
            StreamWriter sw = new StreamWriter("out.txt", true);
            for (int i = 0; i < dim; i++)
                sw.Write("{0} ", x[i]);
            sw.WriteLine();
            sw.Close();
        }

    }


}
